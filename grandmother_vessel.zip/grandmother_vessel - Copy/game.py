import sys
import random
import math

import pygame

from scripts.utils import load_image, load_images, Animation
from scripts.entities import PhysicsEntity, Player
from scripts.tilemap import Tilemap
from scripts.clouds import Clouds
from scripts.void import Void
from scripts.particle import Particle
from scripts.number_display import Numbers

class Game:
    def __init__(self):
        pygame.init()

        self.screen = pygame.display.set_mode((1260, 720))
        self.display = pygame.Surface((320, 180), pygame.SRCALPHA)
        self.display_2 = pygame.Surface((320, 180))

        self.clock = pygame.time.Clock()

        self.movement = [False, False]
        self.vert = [False, False]

        self.assets = {
            'fence': load_images('tiles/fence'),
            'stone': load_images('tiles/stone'),
            'stone_ridge_right': load_images('tiles/stone_ridge_right'),
            'stone_ridge_left': load_images('tiles/stone_ridge_left'),
            'spikes': load_images('tiles/spikes'),
            'laser_shooter': load_images('tiles/laser_shooter'),
            'orb': load_images('tiles/orb'),
            'coin': load_images('tiles/coin'),
            'checkpoint': load_images('tiles/checkpoint'),
            'player': load_image('entities/player.png'),
            'background': load_image('background.png'),
            'void': load_image('void.png'),
            'clouds': load_images('clouds'),
            'player/idle': Animation(load_images('entities/player/idle'), img_dur=6),
            'player/run': Animation(load_images('entities/player/run'), img_dur=4),
            'player/jump': Animation(load_images('entities/player/jump'), img_dur=5, loop=False),
            'player/fall': Animation(load_images('entities/player/fall'), img_dur=4, loop=False),
            'player/slide': Animation(load_images('entities/player/slide')),
            'player/wall_slide': Animation(load_images('entities/player/idle')),
            'particle/orb': Animation(load_images('particles/orb'), img_dur=20, loop=False),
            'particle/dust': Animation(load_images('particles/dust'), img_dur=5, loop=False),
            'particle/dash': Animation(load_images('particles/dash'), img_dur=5, loop=False),
            'particle/void': Animation(load_images('particles/void'), img_dur=10, loop=False),
            'particle/confetti_1': Animation(load_images('particles/confetti_1'), img_dur=10, loop=False),
            'particle/confetti_2': Animation(load_images('particles/confetti_2'), img_dur=10, loop=False),
            'particle/confetti_3': Animation(load_images('particles/confetti_3'), img_dur=10, loop=False),
            'particle/confetti_4': Animation(load_images('particles/confetti_4'), img_dur=10, loop=False),
            'numbers': load_images('numbers'),
            'cage': load_image('cage.png'),
            'statue': load_image('statue.png'),
            'button_top': load_image('button_top.png'),
            'button_bottom': load_image('button_bottom.png'),
            'chain': load_image('chain.png'),
            'menu_background': load_image('GUI/menu_background.png'),
            'play_button_on': load_image('GUI/buttons/play_button_on.png'),
            'play_button_off': load_image('GUI/buttons/play_button_off.png'),
            'oldman_button_on': load_image('GUI/buttons/oldman_button_on.png'),
            'oldman_button_off': load_image('GUI/buttons/oldman_button_off.png'),
            'arrow': load_image('GUI/arrow.png')
        }

        self.clouds = Clouds(self.assets['clouds'], count=16)

        self.void = Void((0, -90), self.assets['void'], 1)
        self.void_pos = 200
        self.checkpoint_void_pos = 200

        self.number_display_1 = Numbers((0, 0), self.assets['numbers'][0], 1)
        self.number_display_2 = Numbers((0, -90), self.assets['numbers'][0], 1)
        self.number_display_3 = Numbers((0, -90), self.assets['numbers'][0], 1)

        self.laser_shoot = 0
        self.laser_shoot_rate = 0

        self.player = Player(self, (50, 50), (8, 8))

        self.tilemap = Tilemap(self, tile_size=8)
        self.tilemap.load('map.json')

        self.orb_particle_spawner = []
        for orbs in self.tilemap.extract([('orb', 0)], keep=True):
            self.orb_particle_spawner.append(pygame.Rect(4 + orbs['pos'][0], 4 + orbs['pos'][1], 8, 8))

        self.orb_rect = []
        for orbs in self.tilemap.extract([('orb', 0)], keep=True):
            self.orb_rect.append(pygame.Rect(4 + orbs['pos'][0], 4 + orbs['pos'][1], 8, 8))

        self.particles = []

        self.scroll = [0, 0]

        self.screenshake = 0

        self.void_distance = 0

        self.button_rect  = pygame.Rect(747, -2368, 24, 6)
        self.button_pos = -2378
        self.button_collide = False

        self.cage_pos = -2392

        self.cage_cutscene = 0

        self.in_menu = True
        self.menu_selected = 0

        self.menu_list = [[120, 70], [170, 70]]

    def menu(self):
        while self.in_menu == True:
            pygame.display.set_caption('Grandmother Vessel')

            self.display.fill((0, 0, 0, 0))
            self.display_2.blit(self.assets['background'], (0, 0))

            self.clouds.update()
            self.clouds.render(self.display_2, offset=(0, 0))

            self.display.blit(self.assets['menu_background'], (0, 0))

            if self.menu_selected == 0:
                self.display.blit(self.assets['play_button_on'], self.menu_list[0])
            else:
                self.display.blit(self.assets['play_button_off'], self.menu_list[0])
            
            if self.menu_selected == 1:
                self.display.blit(self.assets['oldman_button_on'], self.menu_list[1])
            else:
                self.display.blit(self.assets['oldman_button_off'], self.menu_list[1])

            self.display.blit(self.assets['arrow'], (self.menu_list[self.menu_selected][0] + 12, self.menu_list[self.menu_selected][1] + 66))

            self.void.update(150)
            self.void.render(self.display, 170, offset=(0, 0))

            self.player.void_particle((0, 170))

            for particle in self.particles.copy():
                kill = particle.update()
                particle.render(self.display, offset=(0, 0))
                if kill:
                    self.particles.remove(particle)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_a:
                        if self.menu_selected == 0:
                            self.menu_selected = len(self.menu_list) - 1
                        else:
                            self.menu_selected -= 1
                    if event.key == pygame.K_d:
                        if self.menu_selected == len(self.menu_list) - 1:
                            self.menu_selected = 0
                        else:
                            self.menu_selected += 1
                    if event.key == pygame.K_SPACE:
                        if self.menu_selected == 0:
                            self.in_menu = False
                            Game().run(True)
                        if self.menu_selected == 1:
                            self.in_menu = False
                            Game().run(False)
                            
            display_mask = pygame.mask.from_surface(self.display)
            display_sillhouette = display_mask.to_surface(setcolor=(201, 204, 161, 255), unsetcolor=(0, 0, 0, 0))
            for offset in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                self.display_2.blit(display_sillhouette, offset)

            self.display_2.blit(self.display, (0, 0))

            screenshake_offset = (random.random() * self.screenshake - self.screenshake / 2, random.random() * self.screenshake - self.screenshake / 2)
            self.screen.blit(pygame.transform.scale(self.display_2, self.screen.get_size()), screenshake_offset)
            pygame.display.update()
            self.clock.tick(60)

    def run(self, can_die):
        while True:
            timer = int(round(pygame.time.get_ticks(), -3) / 1000)
            timer_digit_1 = timer % 10
            timer_digit_2 = math.trunc((timer % 100) / 10)
            timer_digit_3 = math.trunc((timer % 1000) / 100)

            pygame.display.set_caption('Grandmother Vessel (' + str(round(self.clock.get_fps(), 0)) + " FPS) ")

            self.display.fill((0, 0, 0, 0))
            self.display_2.blit(self.assets['background'], (0, 0))

            self.screenshake = max(0, self.screenshake - 1)

            # Laser functions--------------------

            if self.laser_shoot == 0:
                self.laser_shoot += self.laser_shoot_rate
                self.laser_shoot_rate = 1
            elif self.laser_shoot == 100:
                self.laser_shoot += self.laser_shoot_rate
                self.laser_shoot_rate = -1
            else:
                self.laser_shoot += self.laser_shoot_rate

            # Orb collisions--------------------

            for orbs in self.tilemap.extract([('orb', 0)], keep=True):
                orb_rect  = pygame.Rect(orbs['pos'][0] - 8, orbs['pos'][1] - 8, 16, 16)
                if orb_rect.collidepoint(self.player.pos):
                    self.player.velocity[1] = -3
                    self.player.can_dash = True
                    self.orbing = 60
                    for i in range(7):
                        self.player.orb_particle(orbs['pos'])

            for orbs in self.tilemap.extract([('orb', 1)], keep=True):
                orb_rect  = pygame.Rect(orbs['pos'][0] - 8, orbs['pos'][1] - 8, 16, 16)
                if orb_rect.collidepoint(self.player.pos):
                    self.player.velocity[0] = 3
                    self.player.velocity[1] = -2
                    self.player.can_dash = True
                    for i in range(7):
                        self.player.orb_particle(orbs['pos'])

            for orbs in self.tilemap.extract([('orb', 2)], keep=True):
                orb_rect  = pygame.Rect(orbs['pos'][0] - 8, orbs['pos'][1] - 8, 16, 16)
                if orb_rect.collidepoint(self.player.pos):
                    self.player.velocity[1] = 3
                    self.player.can_dash = True
                    for i in range(7):
                        self.player.orb_particle(orbs['pos'])

            for orbs in self.tilemap.extract([('orb', 3)], keep=True):
                orb_rect  = pygame.Rect(orbs['pos'][0] - 8, orbs['pos'][1] - 8, 16, 16)
                if orb_rect.collidepoint(self.player.pos):
                    self.player.velocity[0] = -3
                    self.player.velocity[1] = -2
                    self.player.can_dash = True
                    for i in range(7):
                        self.player.orb_particle(orbs['pos'])

            # Spike collisions--------------------

            for spikes in self.tilemap.extract([('spikes', 0)], keep=True):
                if self.player.rect().collidepoint(spikes['pos'][0] + 5, spikes['pos'][1]):
                    if can_die:
                        self.player.die()

            for spikes in self.tilemap.extract([('spikes', 2)], keep=True):
                if self.player.rect().collidepoint(spikes['pos'][0], spikes['pos'][1]):
                    if can_die:
                        self.player.die()

            for spikes in self.tilemap.extract([('spikes', 1)], keep=True):
                if self.player.rect().collidepoint(spikes['pos'][0], spikes['pos'][1] + 5):
                    if can_die:
                        self.player.die()

            for spikes in self.tilemap.extract([('spikes', 3)], keep=True):
                if self.player.rect().collidepoint(spikes['pos'][0], spikes['pos'][1]):
                    if can_die:
                        self.player.die()

            # Checkpoint collisions--------------------

            for checkpoint in self.tilemap.extract([('checkpoint', 0)], keep=True):
                if checkpoint['pos'] == self.player.respawn:
                    self.player.checkpoint_particle(checkpoint['pos'])
                elif self.player.rect().collidepoint(checkpoint['pos'][0] + 5, checkpoint['pos'][1]):
                    self.player.respawn[0] = checkpoint['pos'][0]
                    self.player.respawn[1] = checkpoint['pos'][1]
                    self.checkpoint_void_pos = self.void_pos + 20

            # Laser collisions--------------------

            for laser_shooter in self.tilemap.extract([('laser_shooter', 0)], keep=True):
                laser_rect  = pygame.Rect(laser_shooter['pos'][0] - 20, laser_shooter['pos'][1] - 4, 24, 6)
                if self.laser_shoot > 70:
                    self.player.laser_particle((laser_shooter['pos'][0], laser_shooter['pos'][1] + 4), 0)
                    if laser_rect.collidepoint(self.player.pos):
                        if can_die:
                            self.player.die()

            for laser_shooter in self.tilemap.extract([('laser_shooter', 1)], keep=True):
                laser_rect  = pygame.Rect(laser_shooter['pos'][0] - 4, laser_shooter['pos'][1], 6, 24)
                if self.laser_shoot <= 30:
                    self.player.laser_particle((laser_shooter['pos'][0] + 4, laser_shooter['pos'][1] + 8), 1)
                    if laser_rect.collidepoint(self.player.pos):
                        if can_die:
                            self.player.die()

            for laser_shooter in self.tilemap.extract([('laser_shooter', 2)], keep=True):
                laser_rect  = pygame.Rect(laser_shooter['pos'][0], laser_shooter['pos'][1] - 4, 24, 6)
                if self.laser_shoot <= 30:
                    self.player.laser_particle((laser_shooter['pos'][0] + 8, laser_shooter['pos'][1] + 4), 2)
                    if laser_rect.collidepoint(self.player.pos):
                        if can_die:
                            self.player.die()

            for laser_shooter in self.tilemap.extract([('laser_shooter', 3)], keep=True):
                laser_rect  = pygame.Rect(laser_shooter['pos'][0] - 4, laser_shooter['pos'][1] - 20, 6, 24)
                if self.laser_shoot > 70:
                    self.player.laser_particle((laser_shooter['pos'][0] + 4, laser_shooter['pos'][1]), 3)
                    if laser_rect.collidepoint(self.player.pos):
                        if can_die:
                            self.player.die()

            # Void collisions--------------------

            if self.player.pos[1] >= 230:
                self.player.velocity[1] = -5

            if self.player.pos[1] >= self.void_pos:
                if can_die:
                    self.player.die()

            if self.void_pos - self.player.rect().centery < 70:
                try:
                    self.void_distance = 16 / (self.void_pos - self.player.rect().centery)
                except ZeroDivisionError:
                    self.void_distance = 0
            else:
                self.void_distance = 0
            self.screenshake = min(abs(self.void_distance * 16), 16)

            if self.void_pos >= -2200 and can_die == True:
                self.void_pos -= 0.4

            # Cage functions--------------------

            if 180 >= self.cage_cutscene >= 40:
                self.scroll[0] += (814 - self.display.get_width() / 2 - self.scroll[0]) / 30
                self.scroll[1] += (-2360 - self.display.get_height() / 2 - self.scroll[1]) / 30
            elif self.player.pos[1] < 120:
                self.scroll[0] += (self.player.rect().centerx - self.display.get_width() / 2 - self.scroll[0]) / 30
                self.scroll[1] += (self.player.rect().centery - self.display.get_height() / 2 - self.scroll[1]) / 30
            else:
                self.scroll[0] += (self.player.rect().centerx - self.display.get_width() / 2 - self.scroll[0]) / 30
                self.scroll[1] += (120 - self.display.get_height() / 2 - self.scroll[1]) / 30
            render_scroll = (int(self.scroll[0]), int(self.scroll[1]))

            for rect in self.orb_particle_spawner:
                if random.random() * 3000 < rect.width * rect.height:
                    pos = ((rect.x + random.random() * rect.width) - 4, rect.y + random.random() * rect.height)
                    self.particles.append(Particle(self, 'orb', pos, velocity=[-0.1, 0.3], frame=random.randint(0, 2)))

            if self.button_rect.colliderect(self.player.rect()):
                self.button_pos += 2
                self.player.laser_particle((random.randint(744, 770), -2360), 3)
                self.screenshake = 16

            if self.button_pos >= -2360 and self.cage_cutscene <= 180:
                self.cage_cutscene += 1

            if 180 >= self.cage_cutscene >= 80:
                self.screenshake = 16
                self.cage_pos -= 0.5
            if self.cage_cutscene == 181:
                self.player.confetti_particle((804, -2365))
                self.player.confetti_particle((824, -2365))

            # Rendering--------------------

            self.clouds.update()
            self.clouds.render(self.display_2, offset=render_scroll)

            self.button_rect  = pygame.Rect(747, self.button_pos, 16, 6)

            self.display.blit(self.assets['button_top'], (747 - render_scroll[0], self.button_pos - render_scroll[1]))
            self.display.blit(self.assets['button_bottom'], (747 - render_scroll[0], -2376 - render_scroll[1]))

            self.display.blit(self.assets['statue'], (804 - render_scroll[0], -2376 - render_scroll[1]))
            self.display.blit(self.assets['chain'], (814 - render_scroll[0], self.cage_pos - render_scroll[1] - 60))
            self.display.blit(self.assets['cage'], (800 - render_scroll[0], self.cage_pos - render_scroll[1]))

            self.tilemap.render(self.display, offset=render_scroll)

            self.player.update(self.tilemap, (self.movement[1] - self.movement[0], 0))
            self.player.render(self.display, offset=render_scroll)

            self.void.update(self.void_pos)
            self.void.render(self.display, self.void_pos, offset=render_scroll)

            self.player.void_particle((0 + render_scroll[0] + 8 * 2, self.void_pos))

            # Particle functions--------------------

            for particle in self.particles.copy():
                kill = particle.update()
                particle.render(self.display, offset=render_scroll)

                if particle.type == 'orb':
                    particle.pos[0] += math.sin(particle.animation.frame * 0.035) * 0.1 * random.randint(1, 5)
                if kill:
                    self.particles.remove(particle)

            # Key functions--------------------

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_a:
                        self.movement[0] = True
                    if event.key == pygame.K_d:
                        self.movement[1] = True
                    if event.key == pygame.K_r:
                        self.player.die()
                    if event.key == pygame.K_SPACE:
                        self.player.jump()
                    if event.key == pygame.K_LSHIFT:
                        self.player.dash()
                if event.type == pygame.KEYUP:
                    if event.key == pygame.K_a:
                        self.movement[0] = False
                    if event.key == pygame.K_d:
                        self.movement[1] = False
                    if event.key == pygame.K_SPACE and self.player.velocity[1] <= -0.5 and self.player.wall_slide == False and self.player.orbing < 1:
                        self.player.velocity[1] = -0.5

            # Rendering--------------------

            self.number_display_1.update(self.assets['numbers'][timer_digit_1] )
            self.number_display_1.render(self.display, pos=(167, 2))
            self.number_display_2.update(self.assets['numbers'][timer_digit_2] )
            self.number_display_2.render(self.display, pos=(160, 2))
            self.number_display_3.update(self.assets['numbers'][timer_digit_3] )
            self.number_display_3.render(self.display, pos=(153, 2))

            display_mask = pygame.mask.from_surface(self.display)
            display_sillhouette = display_mask.to_surface(setcolor=(201, 204, 161, 255), unsetcolor=(0, 0, 0, 0))
            for offset in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                self.display_2.blit(display_sillhouette, offset)

            self.display_2.blit(self.display, (0, 0))

            screenshake_offset = (random.random() * self.screenshake - self.screenshake / 2, random.random() * self.screenshake - self.screenshake / 2)
            self.screen.blit(pygame.transform.scale(self.display_2, self.screen.get_size()), screenshake_offset)
            pygame.display.update()
            self.clock.tick(60)
Game().menu()