import random

class Void:
    def __init__(self, pos, img, depth):
        self.pos = list(pos)
        self.img = img
        self.depth = depth
    
    def update(self, void_pos):
        self.pos[1] = void_pos
        
    def render(self, surf, void_pos, offset=(0, 0)):
        render_pos = (self.pos[0] - offset[0] * self.depth, void_pos - offset[1] * self.depth)
        surf.blit(self.img, (0, render_pos[1]))