import random

class Numbers:
    def __init__(self, pos, img, depth):
        self.pos = list(pos)
        self.img = img
        self.depth = depth
    
    def update(self, new_img):
        self.img = new_img
        
    def render(self, surf, pos=(50, 50)):
        surf.blit(self.img, pos)